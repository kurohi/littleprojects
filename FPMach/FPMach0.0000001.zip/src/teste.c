#include <image.h>
#include <enhance.h>
#include <minutia.h>
#include <matching.h>

int main(int argc, char **argv){
	image *template,*teste;
	minutia *temp,*test;
	char menu=0;
	double *tempDirecs=NULL, *testDirecs=NULL;
	int penality;
	cvNamedWindow("Template",0);
	cvNamedWindow("Teste",0);
	while(menu!='q'){
		menu = cvWaitKey(0);
		if(menu=='e'){
			template = get_image();
			if(template == NULL) continue;
			show(template,0,0,template->width,template->height,"Template");
			if(tempDirecs == NULL){
				tempDirecs = (double*) malloc(sizeof(double)*template->width/10*template->height/10);
			}
			direction(template,tempDirecs,10,10);
			enhance(template,10,10);
			temp = findMinutia(template,tempDirecs,10,10);
			temp = posprocessing(template,temp,10,10);
			temp = crownCore(template,temp);
			getDistances(temp);
			orderMinutia(temp);
			showMinutia(template,temp,10,10);
		}else if(menu=='r'){
			teste = get_image();
			if(teste == NULL) continue;
			show(teste,0,0,teste->width,teste->height,"Teste");
			if(testDirecs == NULL){
				testDirecs = (double*) malloc(sizeof(double)*teste->width/10*teste->height/10);
			}
			direction(teste,testDirecs,10,10);
			enhance(teste,10,10);
			test = findMinutia(teste,testDirecs,10,10);
			test = posprocessing(teste,test,10,10);
			test = crownCore(teste,test);
			getDistances(test);
			showMinutia(teste,test,10,10);
		}else if(menu == 't'){
			penality = validadeFP(temp,test);
			printf("penalidade: %d\n",penality);
		}else if(menu == 'd'){
			freeMinutiaList(temp);
			freeMinutiaList(test);
			free_image(template);
			free_image(teste);
			temp = test = NULL;
			template = teste = NULL;
		}
	}
	return 0;
}
