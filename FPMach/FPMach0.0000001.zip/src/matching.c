#include <matching.h>

#ifdef USEOPENCV
void showCore(image *img, minutia *delta){
	int x,y;
	IplImage *output = cvCreateImage(cvSize(img->width,img->height),IPL_DEPTH_8U,1);
	for(y=0;y<img->height;y++)
		for(x=0;x<img->width;x++){
			CV_IMAGE_ELEM(output, unsigned char, y,x) = img->data[x+y*img->width];
		}
	for(x=-10;x<10;x++){
		CV_IMAGE_ELEM(output,unsigned char, delta->y-10,delta->x+x) = 255;
		CV_IMAGE_ELEM(output,unsigned char, delta->y+10,delta->x+x) = 255;
	}
	for(y=-10; y<10;y++){
		CV_IMAGE_ELEM(output,unsigned char, delta->y+y,delta->x-10) = 255;
		CV_IMAGE_ELEM(output,unsigned char, delta->y+y,delta->x+10) = 255;
	}
	cvNamedWindow("Delta",0);
	cvShowImage("Delta",output);
	cvWaitKey(0);
	cvDestroyAllWindows();
	cvReleaseImage(&output);
}
#endif

double mod(double num){
	return (num<0.0)?num*-1.0:num;
}

void direction_round(double *direcs, int size){
	int i=0;
	while(i!=size){
		if(direcs[i]>PI){
			direcs[i]-=PI;
		}
		if(direcs[i]<PI/8){
			direcs[i] = 0.0;
		}else if(direcs[i]<PI/4 + PI/8){
			direcs[i] = 1.0;
		}else if(direcs[i]<PI/2 + PI/8){
			direcs[i] = 2.0;
		}else{
			direcs[i] = 3.0;
		}
		i++;
	}
}

minutia *crownCore(image *img, minutia *root){
	image *aux = (image*) malloc (sizeof(image));
	aux->width = img->width;
	aux->height = img->height;
	aux->data = (unsigned char*) malloc (img->width*img->height);

	int x,y,x1,y1,x2,k;
	int size = 5;
	double sigk,poincare,poincareaux;
	double direcs[(img->width/size)*(img->height/size)];
	double d[8*CORERAY];
	double d2[8*(CORERAY+1)];
	int A[(img->width/size)*(img->height/size)];
	memset(A,0,(img->width/size)*(img->height/size)*sizeof(int));
	direction(img, direcs, size,size);
	direction_round(direcs,(img->width/size)*(img->height/size));	

	for(y=0;y<img->height;y++)
		for(x=0;x<img->width;x++){
			aux->data[x+y*img->width] = img->data[x+y*img->width];
		}

	for(y=CORECENTER_Y/size;y<(img->height-CORECENTER_Y)/size; y++)
		for(x=CORECENTER_X/size;x<(img->width-CORECENTER_X)/size; x++){
			poincare = 0.0;
			if((direcs[x+y*img->width/size]==0.0)&&
				(direcs[(x+1)+y*img->width/size]==0.0)&&
				(direcs[(x+1)+(y-1)*img->width/size]==0.0)&&
				(direcs[x+(y-1)*img->width/size]==0.0)){
				continue;
			}
			k=0;
			for(x1=CORERAY;x1>=-CORERAY;x1--){
				d[k++] = direcs[(x+x1)+(y-1)*img->width/size];
			}
			for(y1=-CORERAY+1;y1<=CORERAY;y1++){
				d[k++] = direcs[(x-1)+(y+y1)*img->width/size];
			}
			for(x1=-CORERAY+1;x1<=CORERAY;x1++){
				d[k++] = direcs[(x+x1)+(y+1)*img->width/size];
			}
			for(y1=CORERAY-1;y1>=-CORERAY+1;y1--){
				d[k++] = direcs[(x+1)+(y+y1)*img->width/size];
			}
			for(k=0;k<8*CORERAY;k++){
				sigk = d[(k+1)%(8*CORERAY)] - d[k];
				if(abs(sigk)<=PI/2){
					poincare += sigk;
				}else if(sigk<=-PI/2){
					poincare += PI + sigk;
				}else{
					poincare += PI - sigk;
				}
			}
			poincare /= 2.0*PI;
			if(poincare==0.5){
				A[x+y*img->width/size] = 1;
			}else if(poincare==-0.5){
				A[x+y*img->width/size] = 2;
			}
		}

	for(y=CORECENTER_Y/size;y<(img->height-CORECENTER_Y)/size; y++)
		for(x=CORECENTER_X/size;x<(img->height-CORECENTER_X)/size; x++){
			if(A[x+y*img->width/size]==1){
				k=0;
				for(x1=CORERAY;x1>=-CORERAY;x1--){
					d[k++] = direcs[(x+x1)+(y-1)*img->width/size];
				}
				for(y1=-CORERAY+1;y1<=CORERAY;y1++){
					d[k++] = direcs[(x-1)+(y+y1)*img->width/size];
				}
				for(x1=-CORERAY+1;x1<=CORERAY;x1++){
					d[k++] = direcs[(x+x1)+(y+1)*img->width/size];
				}
				for(y1=CORERAY-1;y1>=-CORERAY+1;y1--){
					d[k++] = direcs[(x+1)+(y+y1)*img->width/size];
				}
				k=0;
				for(x1=(CORERAY+1);x1>=-(CORERAY+1);x1--){
					d2[k++] = direcs[(x+x1)+(y-1)*img->width/size];
				}
				for(y1=-(CORERAY+1)+1;y1<=(CORERAY+1);y1++){
					d2[k++] = direcs[(x-1)+(y+y1)*img->width/size];
				}
				for(x1=-(CORERAY+1)+1;x1<=(CORERAY+1);x1++){
					d2[k++] = direcs[(x+x1)+(y+1)*img->width/size];
				}
				for(y1=(CORERAY+1)-1;y1>=-(CORERAY+1)+1;y1--){
					d2[k++] = direcs[(x+1)+(y+y1)*img->width/size];
				}
				poincare = poincareaux = 0.0;
				for(k=0;k<8*CORERAY;k++){
					sigk = d[(k+1)%(8*CORERAY)] - d[k];
					if(abs(sigk)<=PI/2){
						poincare += sigk;
					}else if(sigk<=-PI/2){
						poincare += PI + sigk;
					}else{
						poincare += PI - sigk;
					}
				}
				for(k=0;k<8*(CORERAY+1);k++){
					sigk = d2[(k+1)%(8*(CORERAY+1))] - d2[k];
					if(abs(sigk)<=PI/2){
						poincareaux += sigk;
					}else if(sigk<=-PI/2){
						poincareaux += PI + sigk;
					}else{
						poincareaux += PI - sigk;
					}
				}
				if(poincare != poincareaux) A[x+y*img->width/size]=0;
			}
		}


	for(y=CORECENTER_Y/size;y<(img->height-CORECENTER_Y)/size; y++)
		for(x=CORECENTER_X/size;x<(img->width-CORECENTER_X)/size; x++){
			if(A[x+y*img->width/size]==1){
				k=0;
				d[k++]=A[(x+1)+y*img->width/size];
				d[k++]=A[(x+1)+(y-1)*img->width/size];
				d[k++]=A[x+(y-1)*img->width/size];
				d[k++]=A[(x-1)+(y-1)*img->width/size];
				d[k++]=A[(x-1)+y*img->width/size];
				d[k++]=A[(x-1)+(y+1)*img->width/size];
				d[k++]=A[x+(y+1)*img->width/size];
				d[k]=A[(x+1)+(y+1)*img->width/size];
				x2=0;
				for(x1=0;x1<=k;x1++){
					x2+=d[x1];
				}
				if(x2==k){
					A[(x+1)+y*img->width/size]=0;
					A[(x+1)+(y-1)*img->width/size]=0;
					A[x+(y-1)*img->width/size]=0;
					A[(x-1)+(y-1)*img->width/size]=0;
					A[(x-1)+y*img->width/size]=0;
					A[(x-1)+(y+1)*img->width/size]=0;
					A[x+(y+1)*img->width/size]=0;
				}else if(x2>k){
					A[(x+1)+y*img->width/size]=0;
					A[(x+1)+(y-1)*img->width/size]=0;
					A[x+(y-1)*img->width/size]=0;
					A[(x-1)+(y-1)*img->width/size]=0;
					A[(x-1)+y*img->width/size]=0;
					A[(x-1)+(y+1)*img->width/size]=0;
					A[x+(y+1)*img->width/size]=0;
					A[(x+1)+(y+1)*img->width/size]=0;
				}
			}else if(A[x+y*img->width/size]==2){
				k=0;
				d[k++]=A[(x+1)+y*img->width/size];
				d[k++]=A[(x+1)+(y-1)*img->width/size];
				d[k++]=A[x+(y-1)*img->width/size];
				d[k++]=A[(x-1)+(y-1)*img->width/size];
				d[k++]=A[(x-1)+y*img->width/size];
				d[k++]=A[(x-1)+(y+1)*img->width/size];
				d[k++]=A[x+(y+1)*img->width/size];
				d[k]=A[(x+1)+(y+1)*img->width/size];
				x2=0;
				for(x1=0;x1<=k;x1++){
					x2+=d[x1];
				}
				if(x2==2*k){
					A[(x+1)+y*img->width/size]=0;
					A[(x+1)+(y-1)*img->width/size]=0;
					A[x+(y-1)*img->width/size]=0;
					A[(x-1)+(y-1)*img->width/size]=0;
					A[(x-1)+y*img->width/size]=0;
					A[(x-1)+(y+1)*img->width/size]=0;
					A[x+(y+1)*img->width/size]=0;
				}else if(x2<2*k){
					A[(x+1)+y*img->width/size]=0;
					A[(x+1)+(y-1)*img->width/size]=0;
					A[x+(y-1)*img->width/size]=0;
					A[(x-1)+(y-1)*img->width/size]=0;
					A[(x-1)+y*img->width/size]=0;
					A[(x-1)+(y+1)*img->width/size]=0;
					A[x+(y+1)*img->width/size]=0;
					A[(x+1)+(y+1)*img->width/size]=0;
				}
			}
		}

	minutia auxm;
	double distance, distanceaux;
	distance=99999999.0;
	for(y=CORECENTER_Y/size;y<(img->height-CORECENTER_Y)/size; y++)
		for(x=CORECENTER_X/size;x<(img->width-CORECENTER_X)/size; x++){
			if(A[x+y*img->width/size]==1){
				distanceaux = ((x*size)-(img->width/2))*((x*size)-(img->width/2));
				distanceaux += ((y*size)-(img->height/2))*((y*size)-(img->height/2));
				if(distanceaux<distance){
					distance = distanceaux;
					auxm.x = x*size;
					auxm.y = y*size;
				}
			}
		}
	minutia *aux2 = root;
	minutia *aux3 = root;
	aux3 = (minutia*) malloc (sizeof(minutia));
	aux3->x = auxm.x;
	aux3->y = auxm.y;
	aux3->type = 3;
	aux3->next = root;

	/*distance = 99999999.0;
	while(aux2 != NULL){
		distanceaux = (aux2->x-auxm.x)*(aux2->x-auxm.x);
		distanceaux += (aux2->y-auxm.y)*(aux2->y-auxm.y);
		if(distanceaux<distance){
			distance = distanceaux;
			aux3 = aux2;
		}
		aux2 = aux2->next;
	}
	if(aux3==root)return aux3;
	aux2 = root;
	while(aux2->next!=aux3) aux2 = aux2->next;
	aux2->next = aux3->next;
	aux3->next = root;
	aux3->type |= CORE;
	aux3->distance = 0;*/
	return aux3;
}

void getDistances(minutia *root){
	minutia *core = root;
	root = root->next;
	while(root!=NULL){
		root->distance = (root->x - core->x)*(root->x - core->x);
		root->distance += (root->y - core->y)*(root->y - core->y);
		root = root->next;
	}
}

static int compMinutia(const void *pt1, const void *pt2){
	minutia **min1 = (minutia**) pt1;
	minutia **min2 = (minutia**) pt2;
	return (*min1)->distance - (*min2)->distance;
}

void orderMinutia(minutia *root){
	int i,mincount=0;
	minutia *aux = root;
	while(aux!=NULL){
		mincount++;
		aux=aux->next;
	}
	minutia *minlist[mincount];
	aux = root;
	for(i=0;i<mincount;i++){
		minlist[i] = aux;
		aux = aux->next;
	}
	qsort(minlist,mincount,sizeof(minutia*),compMinutia);
	for(i=0;i<mincount-1;i++){
		minlist[i]->next = minlist[i+1];
	}
	minlist[i]->next=NULL;
}

int saveTemplate(minutia *root,char *filename){
	FILE *arq;
	if((arq=fopen(filename,"w+"))==NULL){
		//Nao conseguiu abrir o arquivo
		return 0;
	}
	while(root!=NULL){
		fprintf(arq,"(%d,%d)(%lf)(%ld)(%c)\n",root->x,root->y,root->angle,root->distance,root->type);
		root = root->next;
	}
	fclose(arq);
	return 1;
}

int loadTemplate(minutia *root, char *filename){
	FILE *arq;
	if((arq=fopen(filename,"r"))==NULL){
		//Nao conseguiu abrir o arquivo
		return 0;
	}
	char string[100];
	int nminutia = 0;
	while(fread(&string[0],1,1,arq)){
		if(string[0] == '\n') nminutia++;
	}
	fseek(arq,0,SEEK_SET);
	root = (minutia*) malloc(sizeof(minutia));
	fscanf(arq,"(%d,%d)(%lf)(%ld)(%c)\n",&root->x,&root->y,&root->angle,&root->distance,&root->type);
	minutia *aux = root;
	minutia *aux2;
	while(nminutia != 0){
		aux2 = (minutia*) malloc(sizeof(minutia));
		aux->next = aux2;
		aux = aux2;
		fscanf(arq,"(%d,%d)(%lf)(%ld)(%c)\n",&aux->x,&aux->y,&aux->angle,&aux->distance,&aux->type);
		aux->next = NULL;
		nminutia--;
	}
	return 1;
}

double getDistance(minutia *min1, minutia *min2){
	double dist = (min1->x-min2->x)*(min1->x-min2->x);
	dist += (min1->y-min2->y)*(min1->y-min2->y);
	return dist;
}

void centerCores(minutia core,minutia *test){
	int disX,disY;
	disX = core.x - test->x;
	disY = core.y - test->y;
	test = test->next;
	while(test != NULL){
		test->x += disX;
		test->y += disY;
		test = test->next;
	}
}

int validadeFP(minutia *temp, minutia *test){
	minutia *core;
	int i=0;
	long penality = 0;
	int range,delete,include;
	range=delete=include=0;
	centerCores(*temp, test);
	while((test!=NULL)&&(i<MINLIM)){
		core = temp;
		while(core!=NULL){
			if(core->type | OK !=0){
				if(sqrt(getDistance(core,test)) <= CORERANGE){
					range++;
					penality += PEN_TRANSLATE*sqrt(getDistance(core,test));
					test->type |= OK;
					core->type |= OK;
					break;
				}
			}
			core = core->next;
		}
		if(core == NULL){
			delete++;
			penality += PEN_DELETE;
			test->type |= OK;
		}
		i++;
		test = test->next;
	}
	core = temp;
	while(core!=NULL){
		if((core->type &= OK)!=OK){
			include++;
			penality += PEN_INCLUDE;
			core->type |= OK;
		}
		core = core->next;
	}
	if(penality<=PEN_THRESHOLD){
		//return FINGER_MATCH;
	}else{
		//return FINGER_UNMACH;
	}
	printf("Delete: %d\nInclude: %d\nRange: %d\n",delete,include,range);
	return penality;
}
